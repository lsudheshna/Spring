package com.cg.springmvc1.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvc1.dto.Employee;
@Repository("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	EntityManager entitymanager; //entity to connect with DB
	
	@Override
	public void addEmployeeData(Employee emp) {
		entitymanager.persist(emp);
		entitymanager.flush();
		
	}

	@Override
	public List<Employee> showAllEmployee() {
		Query queryOne = entitymanager.createQuery("FROM Employee");
		List<Employee> myList = queryOne.getResultList();
		return myList;
	}

	@Override
	public void deleteEmployee(int empId) 
	{
		Query q3 = entitymanager.createQuery("DELETE FROM Employee where empId=:eid");
		q3.setParameter("eid", empId);
		q3.executeUpdate();
	}

	@Override
	public void updateEmployee(Employee emp) 
	{
		// TODO Auto-generated method stub
		entitymanager.merge(emp);
	}

	@Override
	public List<Employee> searchEmployee(int empId)
	{
		Query query2 = entitymanager.createQuery("FROM Employee where empId=:eid");
		query2.setParameter("eid", empId);
		List<Employee> myList = query2.getResultList();
		return myList;
		
	}

}
