package com.cg.springmvc1.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc1.dao.IEmployeeDao;
import com.cg.springmvc1.dto.Employee;
@Service("employeeservice")
@Transactional //DML statement applicable due to this annotation
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDao employeedao;
	
	@Override
	public void addEmployeeData(Employee emp) {
		employeedao.addEmployeeData(emp);

	}

	@Override
	public List<Employee> showAllEmployee() {
		
		return employeedao.showAllEmployee();
	}

	@Override
	public void deleteEmployee(int empId) {
		
		employeedao.deleteEmployee(empId);
	}

	@Override
	public void updateEmployee(Employee emp) {
	
		employeedao.updateEmployee(emp);
	}

	@Override
	public List<Employee> searchEmployee(int empId) {
		// TODO Auto-generated method stub
		return employeedao.searchEmployee(empId);
	}

}
