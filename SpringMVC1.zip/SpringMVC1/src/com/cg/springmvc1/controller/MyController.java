package com.cg.springmvc1.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc1.dto.Employee;
import com.cg.springmvc1.service.IEmployeeService;

@Controller
public class MyController {

	@Autowired
	IEmployeeService employeeservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)//'all' is url
	public String getAll()
	{
		return "home";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Employee emp, 
			Map<String,Object> model) 
			//temp var=my linking addemployee.jsp to dto Employee
			//to tranfer list to .jsp we use map
	{
		List<String> myDeg = new ArrayList<>();
		myDeg.add("Software Engg");
		myDeg.add("Sr Consultant");
		myDeg.add("Manager");
		model.put("deg", myDeg); //to transfer to jsp like session/request/map 

		return "addemployee";
	}
	
	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String insertEmployee(@ModelAttribute("my") Employee emp)
	{
		//System.out.println("Name is "+emp.getEmpName());
		employeeservice.addEmployeeData(emp);
		return "success";
	}
	
	@RequestMapping(value="show", method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		List<Employee> myAllDate = employeeservice.showAllEmployee();
		return new ModelAndView("showall", "temp", myAllDate); //myAllDate details stored in temp
	}
	
	@RequestMapping(value="search",method=RequestMethod.GET)//'all' is url
	public String search(@ModelAttribute("my") Employee emp)
	{
		return "search";
	}
	
	@RequestMapping(value="searchdata",method=RequestMethod.GET)//'all' is url
	public ModelAndView search(@RequestParam("id")int id,@ModelAttribute("my") Employee emp)
	{
		List<Employee> empList=employeeservice.searchEmployee(id);
		return new ModelAndView("searchdata","temp",empList);
		
	}
	
	@RequestMapping(value="update",method=RequestMethod.GET)//'all' is url
	public String update(@ModelAttribute("my") Employee emp)
	{
		return "update";
	}
	
	@RequestMapping(value="updatedata",method=RequestMethod.GET)//'all' is url
	public ModelAndView updateeach(@RequestParam("uid")int uid,@ModelAttribute("my") Employee emp)
	{
		List<Employee> empList=employeeservice.searchEmployee(uid);
		return new ModelAndView("updatedata","temp",empList);
	}
	
	@RequestMapping(value="updateall",method=RequestMethod.POST)//'all' is url
	public String updateall(@ModelAttribute("my") Employee emp)
	{
		
		employeeservice.updateEmployee(emp);
		return "updatesuccess";
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)//'all' is url
	public String delete()
	{
		return "delete";
	}
	
	@RequestMapping(value="deletedata",method=RequestMethod.GET)//'all' is url
	public ModelAndView delete1(@RequestParam("did")int did)
	{
		List<Employee> empList=employeeservice.searchEmployee(did);
		return new ModelAndView("deletedata","temp",empList);	
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)//'all' is url
	public String delete2(@RequestParam("iid")int iid)
	{
		employeeservice.deleteEmployee(iid);
		return "deletesuccess";
	}
}
