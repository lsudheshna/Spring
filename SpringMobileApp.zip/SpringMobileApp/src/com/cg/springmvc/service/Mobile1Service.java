package com.cg.springmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc.dao.IMobile1Dao;
import com.cg.springmvc.dto.Mobile;


@Service("mobileservice")
@Transactional
public class Mobile1Service implements IMobile1Service
{
	@Autowired
	IMobile1Dao mobiledao;

	@Override
	public List<Mobile> showAllMobile() 
	{
		return mobiledao.showAllMobile();
	}

	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		mobiledao.deleteMobile(mobId);
	}

	@Override
	public void updateMobile(Mobile mob) {
		mobiledao.updateMobile(mob);
		
	}

	@Override
	public List<Mobile> retrieveMobile(int id) {
		// TODO Auto-generated method stub
		return mobiledao.retrieveMobile(id);
	}

}
