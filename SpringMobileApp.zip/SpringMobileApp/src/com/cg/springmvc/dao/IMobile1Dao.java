package com.cg.springmvc.dao;

import java.util.List;

import com.cg.springmvc.dto.Mobile;


public interface IMobile1Dao 
{
	public List<Mobile> showAllMobile();
	
	public void deleteMobile(int mobId);
	
	public void updateMobile(Mobile mob);
	
	public List<Mobile> retrieveMobile(int id);
}
