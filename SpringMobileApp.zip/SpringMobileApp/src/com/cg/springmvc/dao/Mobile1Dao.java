package com.cg.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.dto.Mobile;

@Repository("mobiledao")
public class Mobile1Dao implements IMobile1Dao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public List<Mobile> showAllMobile() 
	{
		Query querone=entitymanager.createQuery("FROM Mobile");
		List<Mobile> allData=querone.getResultList();
		return allData;
	}

	@Override
	public void deleteMobile(int mobId) 
	{
		Query queryTwo=entitymanager.createQuery("DELETE FROM Mobile WHERE mobId=:id");
		queryTwo.setParameter("id", mobId);
		queryTwo.executeUpdate();
		
	}

	@Override
	public void updateMobile(Mobile mob) 
	{
		Query queryFour=entitymanager.createQuery
				("Update Mobile set mobName=:mName,"
						+ "mobCategory=:mCategory,"
						+ "mobPrice=:mprice WHERE mobId=:mId");
		queryFour.setParameter("mId", mob.getMobId());
		queryFour.setParameter("mName", mob.getMobName());
		queryFour.setParameter("mCategory", mob.getMobCategory());
		queryFour.setParameter("mprice", mob.getMobPrice());
		queryFour.executeUpdate();
		
	}

	@Override
	public List<Mobile> retrieveMobile(int id)
	{
		Query queryTwo=entitymanager.createQuery("SELECT m FROM Mobile m WHERE mobId=:mid");
		queryTwo.setParameter("mid", id);
		return queryTwo.getResultList();
	}

	/*@Override
	public void updateMobile(Mobile mob) 
	{
		Query queryThree = entitymanager;
		
	}*/

}
