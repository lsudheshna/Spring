package com.cg.springmvc.controller;

import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc.dto.Mobile;
import com.cg.springmvc.service.IMobile1Service;
import com.cg.springmvc.service.Mobile1Service;



@Controller
public class MobileController 
{
	@Autowired
	IMobile1Service mobileservice;
	
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView allMobileData()
	{
		List<Mobile> mobData = mobileservice.showAllMobile();
		return new ModelAndView("mobileshow","temp",mobData);
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String mobileDelete(@RequestParam("id")int mobid)
	{
		//System.out.println("id is "+mobid);
		mobileservice.deleteMobile(mobid);
		
		return "redirect:/showall";
	}
	
	/*@RequestMapping(value="update",method=RequestMethod.GET)
	public String  updatemobile(@RequestParam("id")int mobid,@ModelAttribute("my") Mobile m)
	{
		System.out.println("id is "+mobid);
		return "detailstoupdate";
	}*/
	
	
	@RequestMapping(value="update", method=RequestMethod.GET)
	public ModelAndView traineeUpdate(@RequestParam("id") int mobid,
				@ModelAttribute("my") Mobile t) 		
	{
		List<Mobile> myData =mobileservice.retrieveMobile(mobid);
		//traineeservice.deleteTrainee(id);
		return new ModelAndView("detailstoupdate","up",myData);
	}
	
	@RequestMapping(value="updatedata",method=RequestMethod.POST)
	public String DetailsToUpdate(@ModelAttribute("my")Mobile mob)
	{
		System.out.println("2345");
		mobileservice.updateMobile(mob);
		return "success";
	}
	
}
